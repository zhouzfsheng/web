/*
    test.c -- Unit test program for GoAhead

    Usage: goahead-test [options] [documents] [endpoints...]
        Options:
        --auth authFile        # User and role configuration
        --home directory       # Change to directory to run
        --log logFile:level    # Log to file file at verbosity level
        --route routeFile      # Route configuration file
        --verbose              # Same as --log stderr:2
        --version              # Output version information

    Copyright (c) All Rights Reserved. See details at the end of the file.
 */

/********************************* Includes ***********************************/

#include    "goahead.h"
#include    "js.h"

/********************************* Defines ************************************/

static int finished = 0;

#undef ME_GOAHEAD_LISTEN
/*
    These must match TOP.es.set
 */
#if TEST_IPV6
#if ME_COM_SSL
    #define ME_GOAHEAD_LISTEN "http://127.0.0.1:18080, https://127.0.0.1:14443, http://[::1]:18090, https://[::1]:14453"
#else
    #define ME_GOAHEAD_LISTEN "http://127.0.0.1:18080, http://[::1]:18090"
#endif
#else
#if ME_COM_SSL
    #define ME_GOAHEAD_LISTEN "http://127.0.0.1:18080, https://127.0.0.1:14443"
#else
    #define ME_GOAHEAD_LISTEN "http://127.0.0.1:18080"
#endif
#endif

/********************************* Forwards ***********************************/

static void initPlatform(void);
static void logHeader(void);
static void usage(void);

static bool testHandler(Webs *wp);
#if ME_GOAHEAD_JAVASCRIPT
static int aspTest(int eid, Webs *wp, int argc, char **argv);
static int bigTest(int eid, Webs *wp, int argc, char **argv);

//new
int createMenuEx(int eid, Webs * wp, int argc, char **argv);
int getInfo(int eid, Webs* wp, int argc, char **argv);
int addHttpNoCache(int eid, Webs * wp, int argc, char ** argv);

#endif
static void actionTest(Webs *wp);
static void sessionTest(Webs *wp);
static void showTest(Webs *wp);
#if ME_GOAHEAD_UPLOAD && !ME_ROM
static void uploadTest(Webs *wp);
#endif
#if ME_GOAHEAD_LEGACY
static int legacyTest(Webs *wp, char *prefix, char *dir, int flags);
#endif
#if ME_UNIX_LIKE
static void sigHandler(int signo);
#endif
static void exitProc(void *data, int id);

/*********************************** Code *************************************/

MAIN(goahead, int argc, char **argv, char **envp)
{
    char    *argp, *auth, *home, *documents, *endpoints, *endpoint, *route, *tok, *lspec;
    int     argind, duration;

    route = "route.txt";
    auth = "auth.txt";
    duration = 0;

    for (argind = 1; argind < argc; argind++) {
        argp = argv[argind];
        if (*argp != '-') {
            break;

        } else if (smatch(argp, "--auth") || smatch(argp, "-a")) {
            if (argind >= argc) usage();
            auth = argv[++argind];

#if ME_UNIX_LIKE && !MACOSX
        } else if (smatch(argp, "--background") || smatch(argp, "-b")) {
            websSetBackground(1);
#endif

        } else if (smatch(argp, "--debugger") || smatch(argp, "-d") || smatch(argp, "-D")) {
            websSetDebug(1);

        } else if (smatch(argp, "--duration")) {
            if (argind >= argc) usage();
            duration = atoi(argv[++argind]);

        } else if (smatch(argp, "--home")) {
            if (argind >= argc) usage();
            home = argv[++argind];
            if (chdir(home) < 0) {
                error("Cannot change directory to %s", home);
                exit(-1);
            }
        } else if (smatch(argp, "--log") || smatch(argp, "-l")) {
            if (argind >= argc) usage();
            logSetPath(argv[++argind]);

        } else if (smatch(argp, "--verbose") || smatch(argp, "-v")) {
            logSetPath("stdout:2");

        } else if (smatch(argp, "--route") || smatch(argp, "-r")) {
            route = argv[++argind];

        } else if (smatch(argp, "--version") || smatch(argp, "-V")) {
            printf("%s\n", ME_VERSION);
            exit(0);

        } else if (*argp == '-' && isdigit((uchar) argp[1])) {
            lspec = sfmt("stdout:%s", &argp[1]);
            logSetPath(lspec);
            wfree(lspec);

        } else {
            usage();
        }
    }
    documents = ME_GOAHEAD_DOCUMENTS;
    if (argc > argind) {
        documents = argv[argind++];
    }
    initPlatform();
    if (websOpen(documents, route) < 0) {
        error("Cannot initialize server. Exiting.");
        return -1;
    }
    logHeader();
    if (websLoad(auth) < 0) {
        error("Cannot load %s", auth);
        return -1;
    }
    if (argind < argc) {
        while (argind < argc) {
            endpoint = argv[argind++];
            if (websListen(endpoint) < 0) {
                return -1;
            }
        }
    } else {
        endpoints = sclone(ME_GOAHEAD_LISTEN);
        for (endpoint = stok(endpoints, ", \t", &tok); endpoint; endpoint = stok(NULL, ", \t,", &tok)) {
            if (getenv("TRAVIS")) {
                if (strstr(endpoint, "::1") != 0) {
                    /* Travis CI does not support IPv6 */
                    continue;
                }
            }
            if (websListen(endpoint) < 0) {
                return -1;
            }
        }
        wfree(endpoints);
    }

    websDefineHandler("test", testHandler, 0, 0, 0);
    websAddRoute("/test", "test", 0);
#if ME_GOAHEAD_LEGACY
    websUrlHandlerDefine("/legacy/", 0, 0, legacyTest, 0);
#endif
#if ME_GOAHEAD_JAVASCRIPT
    websDefineJst("aspTest", aspTest);
    websDefineJst("bigTest", bigTest);
    websDefineJst("getInfo", getInfo);
    websDefineJst("createMenuEx", createMenuEx);
     websDefineJst("addHttpNoCache", addHttpNoCache);
#endif
    websDefineAction("test", actionTest);
    websDefineAction("sessionTest", sessionTest);
    websDefineAction("showTest", showTest);
#if ME_GOAHEAD_UPLOAD && !ME_ROM
    websDefineAction("uploadTest", uploadTest);
#endif

#if ME_UNIX_LIKE && !MACOSX
    /*
        Service events till terminated
    */
    if (websGetBackground()) {
        if (daemon(0, 0) < 0) {
            error("Cannot run as daemon");
            return -1;
        }
    }
#endif
    if (duration) {
        printf("Running for %d secs\n", duration);
        websStartEvent(duration * 1000, (WebsEventProc) exitProc, 0);
    }
    websServiceEvents(&finished);
    logmsg(1, "Instructed to exit\n");
    websClose();
    return 0;
}


static void exitProc(void *data, int id)
{
    websStopEvent(id);
    finished = 1;
}


static void logHeader(void)
{
    char    home[ME_GOAHEAD_LIMIT_STRING];

    getcwd(home, sizeof(home));
    logmsg(2, "Configuration for %s", ME_TITLE);
    logmsg(2, "---------------------------------------------");
    logmsg(2, "Version:            %s", ME_VERSION);
    logmsg(2, "BuildType:          %s", ME_DEBUG ? "Debug" : "Release");
    logmsg(2, "CPU:                %s", ME_CPU);
    logmsg(2, "OS:                 %s", ME_OS);
    logmsg(2, "Host:               %s", websGetServer());
    logmsg(2, "Directory:          %s", home);
    logmsg(2, "Documents:          %s", websGetDocuments());
    logmsg(2, "Configure:          %s", ME_CONFIG_CMD);
    logmsg(2, "---------------------------------------------");
}


static void usage(void) {
    fprintf(stderr, "\n%s Usage:\n\n"
        "  %s [options] [documents] [IPaddress][:port]...\n\n"
        "  Options:\n"
        "    --auth authFile        # User and role configuration\n"
#if ME_UNIX_LIKE && !MACOSX
        "    --background           # Run as a Unix daemon\n"
#endif
        "    --debugger             # Run in debug mode\n"
        "    --home directory       # Change to directory to run\n"
        "    --log logFile:level    # Log to file file at verbosity level\n"
        "    --route routeFile      # Route configuration file\n"
        "    --verbose              # Same as --log stderr:2\n"
        "    --version              # Output version information\n\n",
        ME_TITLE, ME_NAME);
    exit(-1);
}


void initPlatform(void)
{
#if ME_UNIX_LIKE
    signal(SIGINT, sigHandler);
    signal(SIGTERM, sigHandler);
    signal(SIGKILL, sigHandler);
    #ifdef SIGPIPE
        signal(SIGPIPE, SIG_IGN);
    #endif
#elif ME_WIN_LIKE
    _fmode=_O_BINARY;
#endif
}


#if ME_UNIX_LIKE
static void sigHandler(int signo)
{
    finished = 1;
}
#endif


/*
    Simple handler and route test
    Note: Accesses to "/" are normally remapped automatically to /index.html
 */
static bool testHandler(Webs *wp)
{
    if (smatch(wp->path, "/")) {
        websRewriteRequest(wp, "/home.html");
        /* Fall through */
    }
    return 0;
}


#if ME_GOAHEAD_JAVASCRIPT
/*
    Parse the form variables: name, address and echo back
 */
static int aspTest(int eid, Webs *wp, int argc, char **argv)
{
	char	*name, *address;

	if (jsArgs(argc, argv, "%s %s", &name, &address) < 2) {
		websError(wp, 400, "Insufficient args\n");
		return -1;
	}
	return (int) websWrite(wp, "Name: %s, Address %s", name, address);
}

#define BEGIN_CATALOG(name)  	websWrite (wp, "mncata = new menu(\"%s\");", name)
#define FLUSH_CATALOG()  		websWrite (wp, "mnroot.add(mncata);")

#define BEGIN_MENU(name)  		websWrite (wp, "mnpage = new menu(\"%s\");", name)
#define ADD_MENU(link, page)  	websWrite (wp, "mnpage.add(\"%s\",\"%s\");", link, page)
#define END_MENU()  			websWrite (wp, "mncata.add(mnpage);")

int createMenuEx(int eid, Webs * wp, int argc, char **argv)
{
	websWrite(wp, "var mncata = null;\n");
	websWrite(wp, "var mnpage = null;\n");

	//״̬
	//modify by liuxiao 2008-01-23
//	BEGIN_CATALOG("״̬");

//	FLUSH_CATALOG();

    BEGIN_CATALOG("״̬");    //user

    BEGIN_MENU("�豸��Ϣ"); //user
//    ADD_MENU("status_device_basic_info.asp", "�豸������Ϣ");
    END_MENU();

    BEGIN_MENU("�������Ϣ");    //user
    //if (pUser_info->priv) { //admin
    //    ADD_MENU("status_net_connet_info.asp", "IPv4������Ϣ");
    //    ADD_MENU("status_net_connet_info_ipv6.asp", "IPv6������Ϣ");
#ifdef SUPPORT_WAN_BANDWIDTH_INFO
    //    ADD_MENU("status_wan_bandwidth.asp", "WAN������Ϣ");
#endif
    //} else {
    //    ADD_MENU("status_user_net_connet_info.asp", "IPv4������Ϣ");
    //    ADD_MENU("status_user_net_connet_info_ipv6.asp",
    //         "IPv6������Ϣ");
    //}

#ifdef CONFIG_DEV_xDSL
    //if (pUser_info->priv)   //admin
    //    ADD_MENU("status_net_dsl_info.asp", "DSL��Ϣ");   //user- new tech spec
    else
    //    ADD_MENU("status_user_net_dsl_info.asp", "DSL��Ϣ");  //user- new tech spec
#endif

#ifdef CONFIG_EPON_FEATURE
    //if (pon_mode == EPON_MODE)
    //    ADD_MENU("status_epon.asp", "EPON ��Ϣ");
#endif

#ifdef CONFIG_GPON_FEATURE
    //if (pon_mode == GPON_MODE)
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("status_gpon.asp", "PON��·������Ϣ");
        #else
    //    ADD_MENU("status_gpon.asp", "GPON ��Ϣ");
        #endif
#endif

    END_MENU();

    BEGIN_MENU("�û�����Ϣ");    //user
#ifdef WLAN_SUPPORT
#if defined(CONFIG_USB_RTL8192SU_SOFTAP) || defined(CONFIG_RTL8192CD)
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
//    ADD_MENU("status_wlan_info_11n_24g_cmcc.asp", "WLAN2.4G�ӿ���Ϣ");
#if defined(WLAN_DUALBAND_CONCURRENT)
//    ADD_MENU("status_wlan_info_11n_5g_cmcc.asp", "WLAN5G�ӿ���Ϣ");
#endif
#else
//    ADD_MENU("status_wlan_info_11n.asp", "WLAN�ӿ���Ϣ");
#endif
#else
//    ADD_MENU("status_wlan_info.asp", "WLAN�ӿ���Ϣ");
#endif
#endif
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
//    ADD_MENU("status_ethernet_info_cmcc.asp", "LAN�ӿ���Ϣ");
#else
//    ADD_MENU("status_ethernet_info.asp", "��̫���ӿ���Ϣ");

#ifdef CONFIG_USER_LANNETINFO
    //    ADD_MENU("status_lan_net_info.asp", "�¹��豸��Ϣ");
#endif
#endif

#ifdef CONFIG_USER_LAN_BANDWIDTH_MONITOR
{
    //unsigned char vChar=0;
   // mib_get(MIB_LANHOST_BANDWIDTH_MONITOR_ENABLE, (void*)&vChar);
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
    //if(vChar)
    //    ADD_MENU("status_lan_bandwidth_monitor.asp", "�¹��豸���������Ϣ");
#endif
}
#endif

#ifdef USB_SUPPORT
//    ADD_MENU("status_usb_info.asp", "USB�ӿ���Ϣ");
#endif
#ifdef CONFIG_YUEME
//    ADD_MENU("status_plug_in_module.asp", "���ܲ����Ϣ");
#endif
    END_MENU();

#ifdef VOIP_SUPPORT
    //SD6-bohungwu, e8c voip
    BEGIN_MENU("����������Ϣ");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
//    ADD_MENU("cmcc_status_voip_info.asp", "����������Ϣ");
#else
//    ADD_MENU("status_voip_info.asp", "����������Ϣ");
#endif
    END_MENU();
#endif //#ifdef VOIP_SUPPORT

#ifdef E8B_NEW_DIAGNOSE
    //if (pUser_info->priv)   //admin
    {
        BEGIN_MENU("Զ�̹���״̬");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("status_tr069_info_admin_cmcc.asp", "��������");
    //    ADD_MENU("status_tr069_config_admin_cmcc.asp", "ҵ�������·�״̬");
#else
    //    ADD_MENU("status_tr069_info_admin.asp", "Զ�����ӽ���״̬");
    //    ADD_MENU("status_tr069_config_admin.asp", "ҵ�������·�״̬");
#endif
#ifdef CONFIG_USER_CTMANAGEDEAMON
        //mib_get(MIB_BUCPE_ENABLE, &pucpe);
        //if (pucpe)
        //    ADD_MENU("status_bucpe_location_admin.asp", "����λ����Ϣ״̬");
#endif
        END_MENU();

#ifdef CONFIG_USER_CUMANAGEDEAMON
        BEGIN_MENU("���ܹ���ƽ̨״̬");
    //    ADD_MENU("status_cumanage_info_admin_cu.asp", "����ƽ̨״̬");
        END_MENU();
#endif
    }
#endif

#ifdef CONFIG_YUEME 
    BEGIN_MENU("����Ӧ�ù���");
//    ADD_MENU("status_intellappl_connect_info.asp", "������������״̬");
//    ADD_MENU("status_plug_in_config.asp", "��������·�״̬");
    END_MENU();
#endif

    FLUSH_CATALOG();
    //modify end by liuxiao 2008-01-23

    //��  ��
    BEGIN_CATALOG("��  ��");  //user

    //if (pUser_info->priv)   //admin
    {
        BEGIN_MENU("��������");
#if defined(CONFIG_ETHWAN)
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU
    //        ("boaform/formWanRedirect?redirect-url=/net_eth_links_cmcc.asp&if=eth",
    //         "��������");
#else
    //    ADD_MENU
    //        ("boaform/formWanRedirect?redirect-url=/net_eth_links.asp&if=eth",
    //         "Internet ����");
#endif
#endif
#if defined(CONFIG_PTMWAN)
    //    ADD_MENU
    //        ("boaform/formWanRedirect?redirect-url=/net_eth_links.asp&if=ptm",
    //         "Internet PTM ����");
#endif
#if defined(CONFIG_RTL8672_SAR)
    //    ADD_MENU("net_adsl_links.asp", "Internet PVC ����");
#endif
        END_MENU();
#if defined(CONFIG_RTL867X_VLAN_MAPPING) || defined(CONFIG_APOLLO_ROMEDRIVER)
        BEGIN_MENU("������");
    //    ADD_MENU("net_vlan_mapping.asp", "��ģʽ");
        END_MENU();
#endif
    }
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    else
    {
        unsigned char user_wansetget;   
        mib_get(PROVINCE_JIANGSU_USERACCOUNT_WANSETGET,&user_wansetget);
        if(user_wansetget)
        {
            BEGIN_MENU("��������");
        //    ADD_MENU
                ("net_eth_links_user_cmcc.asp","��������");
            END_MENU();
        }
    }
#endif

#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //if (pUser_info->priv)   //admin
#endif
    {
    BEGIN_MENU("LAN���ַ����");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
//    ADD_MENU("net_dhcpd_cmcc.asp", "IPv4����");
#else
//    ADD_MENU("net_dhcpd.asp", "IPv4����");
#endif
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("net_ipv6_cmcc.asp", "IPv6 ����");
#else
    //    ADD_MENU("ipv6.asp", "IPv6 ����");
#endif
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
//    ADD_MENU("dhcpdv6.asp", "IPv6 DHCP Server����");
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("radvdconf.asp", "RA ����");
    }
#endif
    END_MENU();
    }
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    else   //User
    {
        unsigned char InformType = 0;

        mib_get(PROVINCE_CWMP_INFORM_TYPE, &InformType);
        if (InformType == CWMP_INFORM_TYPE_CMCC_SHD)
        {
            BEGIN_MENU("LAN���ַ����");
        //    ADD_MENU("net_dhcpd_cmcc.asp", "IPv4����");
        //    ADD_MENU("net_ipv6_cmcc.asp", "IPv6 ����");
            END_MENU();
        }
    }
#endif
#if defined(CONFIG_USER_PPTP_CLIENT_PPTP) || defined(CONFIG_USER_L2TPD_L2TPD)
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
#else
    //if (pUser_info->priv){

        BEGIN_MENU("VPN WAN"); //user
    //    ADD_MENU("pptp.asp", "PPTP");   
    //    ADD_MENU("l2tp.asp", "L2TP");   
        END_MENU();
    }
#endif
#endif

#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //if (pUser_info->priv){
            BEGIN_MENU("QoS");  
        //    ADD_MENU("net_qos_imq_policy.asp", "����QoS����");
        //    ADD_MENU("net_qos_data_speed_limit.asp", "��������");
            END_MENU();
    }
#endif

#ifdef WLAN_SUPPORT
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    BEGIN_MENU("WLAN2.4G��������"); //user
#else
    BEGIN_MENU("WLAN����");   //user
#endif
#if defined(CONFIG_USB_RTL8192SU_SOFTAP) || defined(CONFIG_RTL8192CD)
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //if (pUser_info->priv)   //admin
    //    ADD_MENU("boaform/admin/formWlanRedirect?redirect-url=/net_wlan_basic_11n_24g_cmcc.asp&wlan_idx=0", "WLAN2.4G��������");
    else
    //    ADD_MENU("boaform/admin/formWlanRedirect?redirect-url=/net_wlan_basic_11n_24g_user_cmcc.asp&wlan_idx=0", "WLAN2.4G��������");
#else
    //if (pUser_info->priv)   //admin
    //    ADD_MENU("net_wlan_basic_11n.asp", "WLAN����");
    else
    //    ADD_MENU("net_wlan_basic_user_11n.asp", "WLAN����");
#endif
#else
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //if (pUser_info->priv)   //admin
    //    ADD_MENU("net_wlan_basic_cmcc.asp", "WLAN����");
    else
    //    ADD_MENU("net_wlan_basic_user_cmcc.asp", "WLAN����");
#else
    //if (pUser_info->priv)   //admin
    //    ADD_MENU("net_wlan_basic.asp", "WLAN����");
    else
    //    ADD_MENU("net_wlan_basic_user.asp", "WLAN����");
#endif
#endif
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
#ifdef WIFI_TIMER_SCHEDULE
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("net_wlan_sched.asp", "���ض�ʱ");
    //    ADD_MENU("net_wlan_timer.asp", "���ض�ʱ(����)");
    }
#endif
#endif
#ifdef _PRMT_X_CMCC_WLANSHARE_
    //if (pUser_info->priv)   //admin
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("net_wlan_share.asp", "WLAN2.4G��������");
#else
    //    ADD_MENU("net_wlan_share.asp", "WLAN��������");
#endif
#endif
    END_MENU();
#endif
/********************************************************************************/  
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
#ifdef WLAN_SUPPORT
#ifdef WLAN_DUALBAND_CONCURRENT
    BEGIN_MENU("WLAN5G��������");   //user

#if defined(CONFIG_USB_RTL8192SU_SOFTAP) || defined(CONFIG_RTL8192CD)
    //if (pUser_info->priv)   //admin
    //    ADD_MENU("boaform/admin/formWlanRedirect?redirect-url=/net_wlan_basic_11n_5g_cmcc.asp&wlan_idx=1", "WLAN5G��������");
    else
    //    ADD_MENU("boaform/admin/formWlanRedirect?redirect-url=/net_wlan_basic_11n_5g_cmcc.asp&wlan_idx=1", "WLAN5G��������");
#endif
    END_MENU();
#endif
#endif
#endif
//////////////////////////////////////////////////////////////////////////////////  
    
#ifdef CONFIG_CU
    BEGIN_MENU("Զ�̹���");
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("net_tr069_cmcc.asp", "RMS������");
    }
//    ADD_MENU("usereg_inside_loid_cmcc.asp", "LOID����");
    END_MENU();
#elif defined(CONFIG_CMCC)
    BEGIN_MENU("Զ�̹���");
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("net_tr069_cmcc.asp", "ʡ�����ּ�ͥ����ƽ̨������");
    }
    if(getWebLoidPageEnable()==1)
    {
    //    ADD_MENU("usereg_inside_loid_cmcc.asp", "LOID��֤");
    }
//    ADD_MENU("usereg_inside_menu_cmcc.asp", "��֤");
    END_MENU();
#else
    //if (pUser_info->priv)   //admin
    {
        BEGIN_MENU("Զ�̹���");
    //    ADD_MENU("net_tr069.asp", "ITMS������");
    //    ADD_MENU("net_certca.asp", "�ϴ�CA֤��");
#ifdef CONFIG_MIDDLEWARE
    //    ADD_MENU("net_midware.asp", "�м������");
#endif
    //    ADD_MENU("usereg_inside_menu.asp", "�߼�IDע��");
        END_MENU();
    }
#endif

    //if (pUser_info->priv)   //admin
    {
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
#else
        BEGIN_MENU("QoS");
      //  //ADD_MENU("net_qos_queue.asp", "��������");
    /*
#ifndef QOS_SETUP_IMQ
    //    ADD_MENU("net_qos_policy.asp", "��������");
#else
    //    ADD_MENU("net_qos_imq_policy.asp", "��������");
#endif
*/
        
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("net_qos_imq_policy.asp", "����QoS����");
#else
    //    ADD_MENU("net_qos_imq_policy.asp", "��������");
    //    ADD_MENU("net_qos_cls.asp", "QoS����");
#endif
//  //    ADD_MENU("net_qos_app.asp", "QoSҵ��");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("net_qos_data_speed_limit.asp", "��������");
#else
    //    ADD_MENU("net_qos_traffictl.asp", "��������");
#endif
        END_MENU();
#endif
        BEGIN_MENU("ʱ�����");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("net_sntp_cmcc.asp", "ʱ�����");
#else
    //    ADD_MENU("net_sntp.asp", "ʱ�������");
#endif
        END_MENU();

        BEGIN_MENU("·������");
        // Mason Yu. 2630-e8b
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
    //    ADD_MENU("rip.asp", "��̬·��");
#endif
        // Mason Yu. 2630-e8b
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("routing_cmcc.asp", "��̬·��");
#else
    //    ADD_MENU("routing.asp", "��̬·��");
#endif

        END_MENU();

#ifdef CONFIG_CU
        BEGIN_MENU("Ŀ�ĵ�ַת����");
    //    ADD_MENU("ipforward_list.asp", "Ŀ�ĵ�ַת����");
        END_MENU();
#endif      

#if 0//defined(CONFIG_CMCC)
        BEGIN_MENU("VLAN����");
    //    ADD_MENU("net_vlan_cfg.asp","VLAN����");
        END_MENU();
#endif

#if 0//defined(CONFIG_CMCC)
        BEGIN_MENU("��VLAN�鲥");
    //    ADD_MENU("net_cross_vlan_cmcc.asp","��VLAN�鲥");
        END_MENU();
#endif

#if 0//defined(CONFIG_CMCC)
#ifdef CONFIG_IPV6
            BEGIN_MENU("IPv6��");
        //    ADD_MENU("net_ipv6_binding.asp","IPv6��");
            END_MENU();
#endif
#endif
    }

    FLUSH_CATALOG();

    //��  ȫ
    BEGIN_CATALOG("��  ȫ");  //user

    BEGIN_MENU("��������������");  //user
//    ADD_MENU("secu_urlfilter_cfg.asp", "��������������");
    END_MENU();

    BEGIN_MENU("����ǽ");
#if defined(CONFIG_CMCC)
//    ADD_MENU("secu_firewall_level_cmcc.asp", "��ȫ��");    //user
#else
//    ADD_MENU("secu_firewall_level.asp", "��ȫ��"); //user
#endif
#if !defined(CONFIG_CMCC)
    //if (pUser_info->priv)   //admin
#endif
    {
    //    ADD_MENU("secu_firewall_dosprev.asp", "������������");
    }
    END_MENU();

    BEGIN_MENU("MAC����");    //user
#ifdef  MAC_FILTER_SRC_ONLY
//    ADD_MENU("secu_macfilter_src.asp", "MAC����");
#else
//    ADD_MENU("secu_macfilter_bridge.asp", "�Ž�MAC����");
//    ADD_MENU("secu_macfilter_router.asp", "·��MAC����");
#endif
    END_MENU();

    //if (pUser_info->priv)   //admin
    {
        BEGIN_MENU("�˿ڹ���");
    //    ADD_MENU("secu_portfilter_cfg.asp", "�˿ڹ���");
        END_MENU();
    }

    FLUSH_CATALOG();

    //Ӧ  ��
    
    BEGIN_CATALOG("Ӧ  ��");  
    
    //if (pUser_info->priv)   //admin
    {
#ifdef CONFIG_RG_SLEEPMODE_TIMER
        BEGIN_MENU("������������");
    //    ADD_MENU("app_sleepmode_rule.asp", "������������");
        END_MENU();
#endif
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
#ifdef CONFIG_LED_INDICATOR_TIMER
        BEGIN_MENU("����LED����");
    //    ADD_MENU("app_led_sched.asp", "����LED����");
        END_MENU();
#endif
#endif
        BEGIN_MENU("DDNS����");
#if defined(CONFIG_CMCC) && !defined(CONFIG_CU)
    //    ADD_MENU("app_ddns.asp", "DDNS����");
#else
    //    ADD_MENU("app_ddns_show.asp", "DDNS����");
#endif
        END_MENU();

        BEGIN_MENU("�߼�NAT����");
        // Mason Yu. 2630-e8b
    //    ADD_MENU("algonoff.asp", "ALG����");
    //    ADD_MENU("fw-dmz.asp", "DMZ����");
    //    ADD_MENU("app_nat_vrtsvr_cfg.asp", "������������");
#if 0
    //    ADD_MENU("app_nat_porttrig_show.asp", "�˿ڴ���");
#endif
        END_MENU();

        BEGIN_MENU("UPNP����");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("app_upnp_cmcc.asp", "UPNP����");
#else
    //    ADD_MENU("app_upnp.asp", "UPNP����");
#endif
#ifdef CONFIG_USER_MINIDLNA
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
    //    ADD_MENU("dms.asp", "DLNA����");
#endif
#endif
        END_MENU();

        //SD6-bohungwu, e8c voip
#ifdef VOIP_SUPPORT
        BEGIN_MENU("�����绰����");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("cmcc_app_voip.asp", "�����绰��������");
    //    ADD_MENU("cmcc_app_voip2.asp", "�����绰�߼�����");
#else
    //    ADD_MENU("app_voip.asp", "�����绰����");
    //    ADD_MENU("app_voip2.asp", "�����绰�߼�����");
#endif  
        END_MENU();
#endif //#ifdef VOIP_SUPPORT

#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
        BEGIN_MENU("IGMP����");
    //    ADD_MENU("app_igmp_snooping.asp", "IGMP SNOOPING");
    //    ADD_MENU("app_igmp_proxy.asp", "IGMP Proxy ");
        END_MENU();

        // Mason Yu. MLD Proxy
        BEGIN_MENU("MLD����");
    //    ADD_MENU("app_mld_snooping.asp", "MLD SNOOPING����"); // Mason Yu. MLD snooping for e8b
    //    ADD_MENU("app_mldProxy.asp", "MLD Proxy����");
        END_MENU();
#else
        BEGIN_MENU("IGMP/MLD����");
    //    ADD_MENU("snooping_proxy_cmcc.asp", "IGMP/MLD����");  
        END_MENU();
#endif
        //if(1==miscfunc_type)
        {
            BEGIN_MENU("�˿�����");
        //    ADD_MENU("app_port_bwcontrol.asp", "�˿�����");
            END_MENU();
        }
        
#if defined (CONFIG_USER_LAN_BANDWIDTH_MONITOR) || defined (CONFIG_USER_LAN_BANDWIDTH_CONTROL)
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
        BEGIN_MENU("�¹��ն�����");
#ifdef CONFIG_USER_LAN_BANDWIDTH_MONITOR
    //    ADD_MENU("app_bandwidth_monitor.asp", "�����д������");
#endif
#ifdef CONFIG_USER_LAN_BANDWIDTH_CONTROL
    //    ADD_MENU("app_bandwidth_control.asp", "�����д�������");
#endif
        END_MENU();
#endif
#endif  // end of (CONFIG_USER_LAN_BANDWIDTH_MONITOR) || defined (CONFIG_USER_LAN_BANDWIDTH_CONTROL)        

#ifdef CONFIG_SUPPORT_CAPTIVE_PORTAL
        BEGIN_MENU("ǿ���Ż�����");
    //    ADD_MENU("url_redirect.asp", "ǿ���Ż�����");
        END_MENU();
#endif
    }
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
else{
        unsigned char InformType = 0;

        mib_get(PROVINCE_CWMP_INFORM_TYPE, &InformType);
        if (InformType == CWMP_INFORM_TYPE_CMCC_SHD)
        {
            BEGIN_MENU("�߼�NAT����");
        //    ADD_MENU("algonoff.asp", "ALG����");
        //    ADD_MENU("fw-dmz.asp", "DMZ����");
        //    ADD_MENU("app_nat_vrtsvr_cfg.asp", "������������");
            END_MENU();
            FLUSH_CATALOG();
        }
    }
#endif  

#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //if(pUser_info->priv)
#endif
    {
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
    BEGIN_MENU("�ճ�Ӧ��"); //user
#ifdef USB_SUPPORT
//    ADD_MENU("app_storage.asp", "��ͥ�洢");
#endif
#ifdef CONFIG_MCAST_VLAN
    //if (pUser_info->priv)
    //    ADD_MENU("app_iptv.asp", "IPTV");
#endif
    END_MENU();
#endif
    }

#if !defined(USB_SUPPORT) || defined(CONFIG_CMCC) || defined(CONFIG_CU)
//if(pUser_info->priv)
#endif
    FLUSH_CATALOG();

    //��  ��
    BEGIN_CATALOG("��  ��");  //user

    BEGIN_MENU("�û�����"); //user
//    ADD_MENU("mgm_usr_user.asp", "�û�����");
    END_MENU();

    BEGIN_MENU("�豸����");
//    ADD_MENU("mgm_dev_reboot.asp", "�豸����"); //user
    //if (pUser_info->priv)   //admin
    //{
#if defined(CONFIG_CMCC)
    //    ADD_MENU("mgm_dev_reset_cmcc.asp", "�ָ�����");
#else
    //    ADD_MENU("mgm_dev_reset.asp", "�ָ���������");
#endif
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    /*}else
    {
        unsigned char InformType = 0;

        mib_get(PROVINCE_CWMP_INFORM_TYPE, &InformType);
        if (InformType != CWMP_INFORM_TYPE_CMCC_SHD)
        //    ADD_MENU("mgm_dev_reset_user_cmcc.asp", "�ָ�����");
    }*/
#endif
#ifdef USB_SUPPORT
#if !defined(CONFIG_CMCC) && !defin8ed(CONFIG_CU)
//    ADD_MENU("mgm_dev_usbbak.asp", "USB��������");
//    ADD_MENU("mgm_dev_usb_umount.asp", "USBж��");
#else
#ifdef CONFIG_CU
//    ADD_MENU("mgm_dev_usb_umount.asp", "USBж��");
#endif
#endif
#endif
    END_MENU();

    //if (pUser_info->priv)   //admin
    {
        BEGIN_MENU("��־�ļ�����");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("mgm_log_cfg_cmcc.asp", "����");
    //    ADD_MENU("mgm_log_view_cmcc.asp", "��־�鿴");
#else
    //    ADD_MENU("mgm_log_cfg.asp", "д��ȼ�����");
    //    ADD_MENU("mgm_log_view.asp", "�豸��־");
#endif
        END_MENU();
        
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
        BEGIN_MENU("ά��");
    //    ADD_MENU("mgm_mnt_mnt.asp", "ά��");
        END_MENU();
#else
#ifdef CONFIG_CU
        BEGIN_MENU("ά��");
    //    ADD_MENU("mgm_mnt_mnt.asp", "ά��");
        END_MENU();
#endif
#endif
    }

    FLUSH_CATALOG();

#ifdef E8B_NEW_DIAGNOSE
    //if (pUser_info->priv)   //admin
    {
        //���
        BEGIN_CATALOG("���");

        BEGIN_MENU("�������");
#ifdef CONFIG_RTL8672_SAR
    //    ADD_MENU("diag_f5loop_admin.asp", "��·����");
#endif
    //    ADD_MENU("diag_ping_admin.asp", "PING����");
    //    ADD_MENU("diag_tracert_admin.asp", "Tracert����");
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    //    ADD_MENU("diagnose_tr069_admin_cmcc.asp", "Inform�ֶ��ϱ�");
#else
    //    ADD_MENU("diagnose_tr069_admin.asp", "�ֶ��ϱ� Inform");
#endif
#ifdef CONFIG_SUPPORT_AUTO_DIAG
#if !defined(CONFIG_CMCC) && !defined(CONFIG_CU)
    //    ADD_MENU("diag_autosystem_admin.asp", "�������ϵͳ");
#endif
#endif
        END_MENU();

#ifdef CONFIG_USER_RTK_LBD
#if !defined(CONFIG_CMCC) //&& !defined(CONFIG_CU)
        BEGIN_MENU("��·���");
    //    ADD_MENU("diag_loopback_detect.asp", "��·���");
        END_MENU();
#endif
#endif

#ifdef VOIP_SUPPORT
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
        BEGIN_MENU("VoIP���");
    //    ADD_MENU("auto_call_voip.asp", "VoIP���");
#else
        BEGIN_MENU("ҵ�����");
    //    ADD_MENU("diag_voip.asp", "�������");
#endif  
        END_MENU();
#endif //#ifdef VOIP_SUPPORT

        FLUSH_CATALOG();
    }
#endif

    //��  ��
    //modify by liuxiao 2008-01-23
    BEGIN_CATALOG("��  ��");  //user
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
    BEGIN_MENU("״̬");
//    ADD_MENU("/help_cmcc/help_status_device.html", "�豸��Ϣ");
//    ADD_MENU("/help_cmcc/help_status_net.asp", "�������Ϣ");
//    ADD_MENU("/help_cmcc/help_status_user.html", "�û�����Ϣ");
#ifdef VOIP_SUPPORT
//    ADD_MENU("/help/help_status_voip.html", "����������Ϣ");
#endif
    //if (pUser_info->priv)   //admin
    //    ADD_MENU("/help_cmcc/help_status_tr069.html", "Զ�̹���״̬");
    END_MENU();

    BEGIN_MENU("����");
    //if (pUser_info->priv)   //admin
    {
#ifdef CONFIG_DEV_xDSL
    //    ADD_MENU("/help_cmcc/help_net_broadband.html", "��������");
#elif defined(CONFIG_GPON_FEATURE) || defined(CONFIG_EPON_FEATURE)
    //    ADD_MENU("/help_cmcc/help_net_pon.html", "��������");
#endif
    //    ADD_MENU("/help_cmcc/help_net_vlan_binding.html", "������");
    //    ADD_MENU("/help_cmcc/help_net_lan.html", "LAN���ַ����");
    }
#ifdef WLAN_SUPPORT
#if defined(CONFIG_CMCC) || defined(CONFIG_CU)
//    ADD_MENU("/help_cmcc/help_net_wlan.asp", "WLAN2.4G��������");
#ifdef WLAN_DUALBAND_CONCURRENT
//    ADD_MENU("/help_cmcc/help_net_wlan5G.asp", "WLAN5G��������");
#endif
#else
//    ADD_MENU("/help_cmcc/help_net_wlan.asp", "WLAN��������");
#endif
#endif
//    ADD_MENU("/help_cmcc/help_net_remote.asp", "Զ�̹���");
    //if (pUser_info->priv)   //admin
    {   
    //    ADD_MENU("/help_cmcc/help_net_qos.html", "QoS");
    //    ADD_MENU("/help_cmcc/help_net_time.html", "ʱ�����");
    //    ADD_MENU("/help_cmcc/help_net_route.html", "·������");
    }
    END_MENU();

    BEGIN_MENU("��ȫ");
//    ADD_MENU("/help_cmcc/help_security_wanaccess.html", "��������������");
//    ADD_MENU("/help_cmcc/help_security_firewall.html", "����ǽ");
//    ADD_MENU("/help_cmcc/help_security_macfilter.html", "MAC����");
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("/help_cmcc/help_security_portfilter.html", "�˿ڹ���");
    }
    END_MENU();

    //if (pUser_info->priv)   //admin
    {
        BEGIN_MENU("Ӧ��");
    
    //    ADD_MENU("/help_cmcc/help_apply_ddns.html", "DDNS����");
    //    ADD_MENU("/help_cmcc/help_apply_nat.html", "�߼�NAT����");
    //    ADD_MENU("/help_cmcc/help_apply_upnp.html", "UPNP����");
#ifdef VOIP_SUPPORT
    //    ADD_MENU("/help/help_apply_voip.html", "�����绰����");
#endif
    //    ADD_MENU("/help_cmcc/help_apply_igmp.html", "IGMP/MLD����");
        END_MENU();
    }

    BEGIN_MENU("����");
//    ADD_MENU("/help_cmcc/help_manage_user.asp", "�û�����");
//    ADD_MENU("/help_cmcc/help_manage_device.asp", "�豸����");
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("/help_cmcc/help_manage_logfile.html", "��־�ļ�����");
    }
    END_MENU();
    
    //if (pUser_info->priv)   //admin
    {
        BEGIN_MENU("���");
    //    ADD_MENU("/help_cmcc/help_diag_net.html", "�������");
#ifdef VOIP_SUPPORT
    //    ADD_MENU("/help/help_diag_voip.html", "VOIP���");
#endif
        END_MENU();
    }
#else
    BEGIN_MENU("״̬����");
//    ADD_MENU("/help/help_status_device.html", "�豸��Ϣ����");
//    ADD_MENU("/help/help_status_net.asp", "�������Ϣ����");
//    ADD_MENU("/help/help_status_user.html", "�û�����Ϣ����");
#ifdef VOIP_SUPPORT
//    ADD_MENU("/help/help_status_voip.html", "����������Ϣ����");
#endif
    END_MENU();

    BEGIN_MENU("�������");
    ////if (pUser_info->priv) //admin
    {
#ifdef CONFIG_DEV_xDSL
    //    ADD_MENU("/help/help_net_broadband.html", "�������ð���");
#elif defined(CONFIG_GPON_FEATURE) || defined(CONFIG_EPON_FEATURE)
    //    ADD_MENU("/help/help_net_pon.html", "�������ð���");
#endif
    //    ADD_MENU("/help/help_net_dhcp.html", "DHCP���ð���");
    }
#ifdef WLAN_SUPPORT
//    ADD_MENU("/help/help_net_wlan.html", "WLAN���ð���");
#endif
    ////if (pUser_info->priv) //admin
    {
    //    ADD_MENU("/help/help_net_remote.html", "Զ�̹�������");
    //    ADD_MENU("/help/help_net_qos.html", "QoS����");
    //    ADD_MENU("/help/help_net_time.html", "ʱ���������");
    //    ADD_MENU("/help/help_net_route.html", "·�����ð���");
    }
    END_MENU();

    BEGIN_MENU("��ȫ����");
//    ADD_MENU("/help/help_security_wanaccess.html", "�������������ð���");
//    ADD_MENU("/help/help_security_firewall.html", "����ǽ����");
//    ADD_MENU("/help/help_security_macfilter.html", "MAC���˰���");
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("/help/help_security_portfilter.html", "�˿ڹ��˰���");
    }
    END_MENU();

    BEGIN_MENU("Ӧ�ð���");
    ////if (pUser_info->priv) //admin
    {
    //    ADD_MENU("/help/help_apply_ddns.html", "DDNS���ð���");
    //    ADD_MENU("/help/help_apply_nat.html", "�߼�NAT���ð���");
    //    ADD_MENU("/help/help_apply_upnp.html", "UPNP���ð���");
#ifdef VOIP_SUPPORT
    //    ADD_MENU("/help/help_apply_voip.html", "�����绰���ð���");
#endif
    //    ADD_MENU("/help/help_apply_igmp.html", "IGMP���ð���");
    }
#ifdef USB_SUPPORT
//    ADD_MENU("/help/help_apply_familymemory.html", "��ͥ�洢����");
#endif
    END_MENU();

    BEGIN_MENU("��������");
//    ADD_MENU("/help/help_manage_user.html", "�û���������");
//    ADD_MENU("/help/help_manage_device.html", "�豸��������");
    //if (pUser_info->priv)   //admin
    {
    //    ADD_MENU("/help/help_manage_logfile.html", "��־�ļ���������");
    //    ADD_MENU("/help/help_manage_keep.html", "ά������");
    }
    END_MENU();
#endif

    FLUSH_CATALOG();
    //modify end by liuxiao 2008-01-23


	return 0;
}

int getInfo(int eid, Webs* wp, int argc, char **argv)
{
	websWrite(wp, "%s", "H2-3s");
	return 0;
}

int addHttpNoCache(int eid, Webs * wp, int argc, char ** argv)
{
	websWrite(wp, "<HEAD>\n<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\">\n</HEAD>\n");
}

/*
    Generate a large response
 */
static int bigTest(int eid, Webs *wp, int argc, char **argv)
{
    int     i;

    websSetStatus(wp, 200);
    websWriteHeaders(wp, -1, 0);
    websWriteEndHeaders(wp);
    websWrite(wp, "<html>\n");
    for (i = 0; i < 800; i++) {
        websWrite(wp, " Line: %05d %s", i, "aaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbccccccccccccccccccddddddd<br/>\r\n");
    }
    websWrite(wp, "</html>\n");
    websDone(wp);
    return 0;
}
#endif


/*
    Implement /action/actionTest. Parse the form variables: name, address and echo back.
 */
static void actionTest(Webs *wp)
{
	cchar	*name, *address;

	name = websGetVar(wp, "name", NULL);
	address = websGetVar(wp, "address", NULL);
    websSetStatus(wp, 200);
    websWriteHeaders(wp, -1, 0);
    websWriteEndHeaders(wp);
	websWrite(wp, "<html><body><h2>name: %s, address: %s</h2></body></html>\n", name, address);
    websFlush(wp, 0);
	websDone(wp);
}


static void sessionTest(Webs *wp)
{
	cchar	*number;

    if (scaselessmatch(wp->method, "POST")) {
        number = websGetVar(wp, "number", 0);
        websSetSessionVar(wp, "number", number);
    } else {
        number = websGetSessionVar(wp, "number", 0);
    }
    websSetStatus(wp, 200);
    websWriteHeaders(wp, -1, 0);
    websWriteEndHeaders(wp);
    websWrite(wp, "<html><body><p>Number %s</p></body></html>\n", number);
    websDone(wp);
}


static void showTest(Webs *wp)
{
    WebsKey     *s;

    websSetStatus(wp, 200);
    websWriteHeaders(wp, -1, 0);
    websWriteEndHeaders(wp);
    websWrite(wp, "<html><body><pre>\n");
    for (s = hashFirst(wp->vars); s; s = hashNext(wp->vars, s)) {
        websWrite(wp, "%s=%s\n", s->name.value.string, s->content.value.string);
    }
    websWrite(wp, "</pre></body></html>\n");
    websDone(wp);
}


#if ME_GOAHEAD_UPLOAD && !ME_ROM
/*
    Dump the file upload details. Don't actually do anything with the uploaded file.
 */
static void uploadTest(Webs *wp)
{
    WebsKey         *s;
    WebsUpload      *up;
    char            *upfile;

    websSetStatus(wp, 200);
    websWriteHeaders(wp, -1, 0);
    websWriteHeader(wp, "Content-Type", "text/plain");
    websWriteEndHeaders(wp);
    if (scaselessmatch(wp->method, "POST")) {
        for (s = hashFirst(wp->files); s; s = hashNext(wp->files, s)) {
            up = s->content.value.symbol;
            websWrite(wp, "FILE: %s\r\n", s->name.value.string);
            websWrite(wp, "FILENAME=%s\r\n", up->filename);
            websWrite(wp, "CLIENT=%s\r\n", up->clientFilename);
            websWrite(wp, "TYPE=%s\r\n", up->contentType);
            websWrite(wp, "SIZE=%d\r\n", up->size);
            upfile = sfmt("%s/tmp/%s", websGetDocuments(), up->clientFilename);
            if (rename(up->filename, upfile) < 0) {
                error("Cannot rename uploaded file: %s to %s, errno %d", up->filename, upfile, errno);
            }
            wfree(upfile);
        }
        websWrite(wp, "\r\nVARS:\r\n");
        for (s = hashFirst(wp->vars); s; s = hashNext(wp->vars, s)) {
            websWrite(wp, "%s=%s\r\n", s->name.value.string, s->content.value.string);
        }
    }
    websDone(wp);
}
#endif


#if ME_GOAHEAD_LEGACY
/*
    Legacy handler with old parameter sequence
 */
static int legacyTest(Webs *wp, char *prefix, char *dir, int flags)
{
    websSetStatus(wp, 200);
    websWriteHeaders(wp, -1, 0);
    websWriteHeader(wp, "Content-Type", "text/plain");
    websWriteEndHeaders(wp);
    websWrite(wp, "Hello Legacy World\n");
    websDone(wp);
    return 1;
}

#endif

/*
    @copy   default

    Copyright (c) Embedthis Software LLC, 2003-2014. All Rights Reserved.

    This software is distributed under commercial and open source licenses.
    You may use the Embedthis GoAhead open source license or you may acquire
    a commercial license from Embedthis Software. You agree to be fully bound
    by the terms of either license. Consult the LICENSE.md distributed with
    this software for full details and other copyrights.

    Local variables:
    tab-width: 4
    c-basic-offset: 4
    End:
    vim: sw=4 ts=4 expandtab

    @end
 */
