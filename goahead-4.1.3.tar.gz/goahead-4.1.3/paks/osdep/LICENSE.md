osdep Licenses
===

This software is distributed under commercial and GPL open source licenses.
The GPL License does not generally permit incorporating this software into
non-open source programs. Commercial licenses for this software and support
services are available.

* [GPL License](http://www.gnu.org/licenses/gpl-2.0.html)
* [Embedthis Commercial License](https://embedthis.com/licensing/)

Trademarks and Copyrights
---
Copyright (c) Michael O'Brien. All Rights Reserved.
