patch-mbedtls
===

A patch for MbedTLS to create an amalgamated release for use by Pak

### Prerequisites:

    Pak (https://embedthis.com/pak/) to install.
    MakeMe (https://embedthis.com/makeme/) for MakeMe to configure and build.

### To Install:

    pak install mbedtls

This will automatically fetch MbedTLS and apply this patch to create an amalgamated release.
