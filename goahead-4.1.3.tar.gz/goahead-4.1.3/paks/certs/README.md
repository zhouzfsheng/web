certs
===

On macosx, use brew install openssl and set PATH to reference the brew openssl.

Test certificates.

## Installation

    pak install certs

## Building

    me

## Get Pak

[https://www.embedthis.com/pak/](https://www.embedthis.com/pak/)
